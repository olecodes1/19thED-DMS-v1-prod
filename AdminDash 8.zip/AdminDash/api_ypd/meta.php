<?php
// GET /api_ypd/meta         -> the single ypd_booklet_meta row (public)
// PUT /api_ypd/meta         -> update cover/foreword/district fields (requires auth)

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';
require_once __DIR__ . '/crud_helper.php';

ypd_send_json_headers();

$pdo = getDb();
$method = $_SERVER['REQUEST_METHOD'];

// OPTIMIZATION: Cache the meta row for 60 seconds (rarely changes)
static $metaCache = null;
static $metaCacheTime = 0;
$cacheTtl = 60; // 60 seconds

if ($method === 'GET') {
    if ($metaCache !== null && (time() - $metaCacheTime) < $cacheTtl) {
        ypd_respond($metaCache);
    }
    $row = $pdo->query('SELECT * FROM ypd_booklet_meta ORDER BY id LIMIT 1')->fetch();
    $metaCache = $row ?: null;
    $metaCacheTime = time();
    ypd_respond($metaCache);
}

if ($method === 'PUT' || $method === 'PATCH') {
    // Require authentication for write operations
    requireAuth();
    
    $data = ypd_json_input();
    $allowed = ['district_name', 'booklet_title', 'subtitle', 'foreword', 'historiographer_name', 'cover_photo_id', 'published_year'];
    $sets = [];
    $params = [];
    foreach ($allowed as $field) {
        if (array_key_exists($field, $data)) {
            $sets[] = "$field = :$field";
            $params[":$field"] = $data[$field];
        }
    }
    if (empty($sets)) {
        ypd_error('No updatable fields provided.', 422);
    }
    if (columnExists($pdo, 'ypd_booklet_meta', 'updated_at')) {
        $sets[] = 'updated_at = ' . (DB_DRIVER === 'mysql' ? 'NOW()' : "datetime('now')");
    }
    $row = $pdo->query('SELECT id FROM ypd_booklet_meta ORDER BY id LIMIT 1')->fetch();
    $params[':id'] = $row['id'];
    $stmt = $pdo->prepare('UPDATE ypd_booklet_meta SET ' . implode(', ', $sets) . ' WHERE id = :id');
    $stmt->execute($params);

    $updated = $pdo->query('SELECT * FROM ypd_booklet_meta ORDER BY id LIMIT 1')->fetch();
    ypd_respond($updated);
}

ypd_error('Method not allowed', 405);
