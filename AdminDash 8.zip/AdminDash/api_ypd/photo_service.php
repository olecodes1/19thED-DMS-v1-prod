<?php
/**
 * photo_service.php — safe photo deletion (§3.5)
 *
 * Deleting a photo must not leave orphaned files or break booklet content,
 * so a photo can only be removed when nothing references it. The physical
 * file is removed only after the row delete succeeds.
 */

require_once __DIR__ . '/db.php';

/**
 * All booklet tables that may hold a photo reference.
 * referenced_table => [table, id column]
 */
function ypd_photo_reference_map(): array
{
    return [
        'Booklet cover'        => ['ypd_booklet_meta', 'cover_photo_id'],
        'Officer portraits'    => ['ypd_officers', 'photo_id'],
        'Mother Directors'     => ['ypd_mother_directors', 'photo_id'],
    ];
}

/**
 * Check where a photo is used. Returns a list of human-readable usage labels.
 */
function ypd_photo_get_references(PDO $pdo, int $photoId): array
{
    $usages = [];
    foreach (ypd_photo_reference_map() as $label => [$table, $column]) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$table} WHERE {$column} = :pid");
        $stmt->execute([':pid' => $photoId]);
        $count = (int) $stmt->fetchColumn();
        if ($count > 0) {
            $usages[] = "$label ($count)";
        }
    }
    return $usages;
}

/**
 * Delete a photo row + its physical file after verifying it is unreferenced.
 * Returns [ok => bool, error => ?string].
 */
function ypd_photo_delete(PDO $pdo, int $photoId): array
{
    $stmt = $pdo->prepare('SELECT * FROM photos WHERE id = :id');
    $stmt->execute([':id' => $photoId]);
    $photo = $stmt->fetch();
    if (!$photo) {
        return [false, 'Photo not found.'];
    }

    // 1. Check references — refuse deletion while content still points here
    $usages = ypd_photo_get_references($pdo, $photoId);
    if ($usages) {
        return [false, 'Photo is still in use by: ' . implode(', ', $usages) . '. Remove the reference first.'];
    }

    // 2. Delete the row (transactional with nothing else — the file only
    //    disappears once the DB no longer knows about the photo)
    $del = $pdo->prepare('DELETE FROM photos WHERE id = :id');
    $del->execute([':id' => $photoId]);

    // 3. Remove the physical file, then log the action
    $filename = basename((string) ($photo['filename'] ?? ''));
    if ($filename !== '' && preg_match('/^[A-Za-z0-9._-]+$/', $filename)) {
        $path = realpath(UPLOAD_DIR . '/' . $filename);
        $base = realpath(UPLOAD_DIR);
        if ($path && $base && strpos($path, $base . DIRECTORY_SEPARATOR) === 0 && is_file($path)) {
            @unlink($path);
        }
    }

    if (function_exists('audit_log')) {
        audit_log('PHOTO_DELETE', "photo_id={$photoId} filename={$filename}");
    }

    return [true, null];
}
