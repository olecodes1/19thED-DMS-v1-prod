<?php
// /api_ypd/photos[/{id}] — gallery metadata (the actual files are handled by upload.php)
// GET is public, POST/PUT/DELETE require authentication.
// DELETE runs through the photo service (§3.5): refuses deletion while any
// booklet content references the photo, and removes the physical file after.

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';
require_once __DIR__ . '/crud_helper.php';
require_once __DIR__ . '/photo_service.php';

ypd_send_json_headers();

$method = $_SERVER['REQUEST_METHOD'];
$id = $GLOBALS['ypd_route_id'] ?? ($_GET['id'] ?? null);

// DELETE is intercepted before the generic CRUD handler
if ($method === 'DELETE') {
    requireAuth();
    if ($id === null) {
        ypd_error('Missing photo id', 400);
    }
    $pdo = getDb();
    $result = ypd_photo_delete($pdo, (int) $id);
    if (!$result[0]) {
        ypd_error($result[1], 409);
    }
    ypd_respond(['deleted' => true, 'id' => (int) $id]);
}

// GET is public; all other writes require authentication
ypd_handle_crud(
    table: 'photos',
    allowedFields: ['caption', 'related_type', 'related_id'], // filename is server-generated via upload.php only (§3.4)
    requiredOnCreate: [],
    orderBy: 'uploaded_at DESC',
    requireAuth: ($method !== 'GET')
);
