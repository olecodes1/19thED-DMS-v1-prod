-- §2.3 Draft/publish workflow for the YPD History Booklet
-- Adds a status column (draft | published) plus publication audit fields
-- to every booklet chapter table. Existing rows become 'published' so the
-- current public booklet is unchanged after migration.
-- Run once. Uses ADD COLUMN IF NOT EXISTS semantics guarded per statement
-- (run statements individually if your MySQL version lacks IF NOT EXISTS).

ALTER TABLE ypd_history_entries
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;

ALTER TABLE ypd_officers
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;

ALTER TABLE ypd_mother_directors
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;

ALTER TABLE ypd_timeline_events
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;

ALTER TABLE ypd_achievements
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;

ALTER TABLE ypd_statistics
    ADD COLUMN IF NOT EXISTS status ENUM('draft','published') NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS published_at DATETIME NULL,
    ADD COLUMN IF NOT EXISTS published_by VARCHAR(100) NULL;
