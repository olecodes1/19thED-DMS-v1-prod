-- §3.2 Date normalization for the YPD Booklet
-- Free-form date strings (e.g. "1915-10", "June 2024") stay as the display
-- value, but normalized numeric columns are added alongside them so sorting
-- and filtering become reliable. Existing rows are backfilled automatically.
-- Safe to re-run: each section checks the columns first.

-- ------------------------------------------------------------------
-- 1. Timeline events: event_date -> event_year / event_month
-- ------------------------------------------------------------------
SET @colExists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_timeline_events' AND COLUMN_NAME = 'event_year');
SET @sql := IF(@colExists = 0,
    'ALTER TABLE ypd_timeline_events ADD COLUMN event_year SMALLINT NULL AFTER event_date',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @colExists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_timeline_events' AND COLUMN_NAME = 'event_month');
SET @sql := IF(@colExists = 0,
    'ALTER TABLE ypd_timeline_events ADD COLUMN event_month TINYINT NULL AFTER event_year',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Backfill: first 4-digit year found in event_date, then month 01-12 if present
UPDATE ypd_timeline_events
SET event_year  = CAST(SUBSTRING(REGEXP_SUBSTR(event_date, '[0-9]{4}'), 1, 4) AS UNSIGNED),
    event_month = CAST(NULLIF(REGEXP_SUBSTR(event_date, '(^|[^0-9])(0?[1-9]|1[0-2])([^0-9]|$)'), '') AS UNSIGNED)
WHERE event_year IS NULL AND event_date IS NOT NULL AND event_date <> ''
  AND REGEXP_SUBSTR(event_date, '[0-9]{4}') IS NOT NULL;

-- ------------------------------------------------------------------
-- 2. Achievements: achievement_date -> achievement_year
-- ------------------------------------------------------------------
SET @colExists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_achievements' AND COLUMN_NAME = 'achievement_year');
SET @sql := IF(@colExists = 0,
    'ALTER TABLE ypd_achievements ADD COLUMN achievement_year SMALLINT NULL AFTER achievement_date',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE ypd_achievements
SET achievement_year = CAST(SUBSTRING(REGEXP_SUBSTR(achievement_date, '[0-9]{4}'), 1, 4) AS UNSIGNED)
WHERE achievement_year IS NULL AND achievement_date IS NOT NULL AND achievement_date <> ''
  AND REGEXP_SUBSTR(achievement_date, '[0-9]{4}') IS NOT NULL;

-- ------------------------------------------------------------------
-- 3. Officers: term_start / term_end -> term_start_year / term_end_year
-- ------------------------------------------------------------------
SET @colExists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_officers' AND COLUMN_NAME = 'term_start_year');
SET @sql := IF(@colExists = 0,
    'ALTER TABLE ypd_officers ADD COLUMN term_start_year SMALLINT NULL AFTER term_end',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @colExists := (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_officers' AND COLUMN_NAME = 'term_end_year');
SET @sql := IF(@colExists = 0,
    'ALTER TABLE ypd_officers ADD COLUMN term_end_year SMALLINT NULL AFTER term_start_year',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE ypd_officers
SET term_start_year = CAST(SUBSTRING(REGEXP_SUBSTR(term_start, '[0-9]{4}'), 1, 4) AS UNSIGNED)
WHERE term_start_year IS NULL AND term_start IS NOT NULL AND term_start <> ''
  AND REGEXP_SUBSTR(term_start, '[0-9]{4}') IS NOT NULL;

UPDATE ypd_officers
SET term_end_year = CAST(SUBSTRING(REGEXP_SUBSTR(term_end, '[0-9]{4}'), 1, 4) AS UNSIGNED)
WHERE term_end_year IS NULL AND term_end IS NOT NULL AND term_end <> ''
  AND REGEXP_SUBSTR(term_end, '[0-9]{4}') IS NOT NULL;
