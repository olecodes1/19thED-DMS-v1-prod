-- Event booklet PDF support
-- Adds a nullable path to the events table so admins can upload a
-- per-event PDF booklet (e.g. convention programme) shown on the public
-- event page. Run once; skip if the column already exists.
ALTER TABLE events
    ADD COLUMN booklet_path VARCHAR(255) NULL AFTER attendance_count;
