-- Force password change for seeded/default accounts (§1.7)
-- Flags existing accounts so they must set a new password before
-- using the dashboard. New logins will be redirected to change_password.
ALTER TABLE users
    ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0;
