-- §7.1 Performance indexes
-- Adds indexes for the most common filters and joins across the app.
-- Safe to re-run: each index is created only if missing (MySQL 5.7-safe
-- pattern using prepared statements; skip the SHOW COLUMNS guard if you
-- are on MariaDB where CREATE INDEX IF NOT EXISTS exists).

-- ------------------------------------------------------------------
-- Members — the app's biggest table (conference/area/church filters,
-- soft-delete, component stats)
-- ------------------------------------------------------------------
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_conference');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_conference (conference_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_area');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_area (area_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_church');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_church (church_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_deleted_at');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_deleted_at (deleted_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_component');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_component (component)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_surname');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_surname (surname_name)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_deleted_church');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_deleted_church (deleted_at, church_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ------------------------------------------------------------------
-- Events / attendance
-- ------------------------------------------------------------------
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'events' AND INDEX_NAME = 'idx_events_date');
SET @sql := IF(@idx = 0, 'ALTER TABLE events ADD INDEX idx_events_date (event_date)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'events' AND INDEX_NAME = 'idx_events_conference');
SET @sql := IF(@idx = 0, 'ALTER TABLE events ADD INDEX idx_events_conference (conference_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'events' AND INDEX_NAME = 'idx_events_conference_date');
SET @sql := IF(@idx = 0, 'ALTER TABLE events ADD INDEX idx_events_conference_date (conference_id, event_date)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_attendance_breakdowns' AND INDEX_NAME = 'idx_breakdowns_event');
SET @sql := IF(@idx = 0, 'ALTER TABLE event_attendance_breakdowns ADD INDEX idx_breakdowns_event (event_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_attendance_breakdowns' AND INDEX_NAME = 'idx_breakdowns_event_attendance');
SET @sql := IF(@idx = 0, 'ALTER TABLE event_attendance_breakdowns ADD INDEX idx_breakdowns_event_attendance (event_id, attendance_count)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ------------------------------------------------------------------
-- Media / stories (soft delete + uploads listing)
-- ------------------------------------------------------------------
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'media_items' AND INDEX_NAME = 'idx_media_deleted_at');
SET @sql := IF(@idx = 0, 'ALTER TABLE media_items ADD INDEX idx_media_deleted_at (deleted_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'media_items' AND INDEX_NAME = 'idx_media_deleted_uploaded');
SET @sql := IF(@idx = 0, 'ALTER TABLE media_items ADD INDEX idx_media_deleted_uploaded (deleted_at, uploaded_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'story_pages' AND INDEX_NAME = 'idx_story_deleted_at');
SET @sql := IF(@idx = 0, 'ALTER TABLE story_pages ADD INDEX idx_story_deleted_at (deleted_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'story_pages' AND INDEX_NAME = 'idx_story_status_deleted_created');
SET @sql := IF(@idx = 0, 'ALTER TABLE story_pages ADD INDEX idx_story_status_deleted_created (status, deleted_at, created_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ------------------------------------------------------------------
-- Booklet: sort fields used by every chapter listing
-- ------------------------------------------------------------------
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_history_entries' AND INDEX_NAME = 'idx_history_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_history_entries ADD INDEX idx_history_sort (sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_officers' AND INDEX_NAME = 'idx_officers_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_officers ADD INDEX idx_officers_sort (sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_mother_directors' AND INDEX_NAME = 'idx_mother_directors_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_mother_directors ADD INDEX idx_mother_directors_sort (sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_timeline_events' AND INDEX_NAME = 'idx_timeline_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_timeline_events ADD INDEX idx_timeline_sort (event_year, sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_achievements' AND INDEX_NAME = 'idx_achievements_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_achievements ADD INDEX idx_achievements_sort (sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ypd_statistics' AND INDEX_NAME = 'idx_statistics_sort');
SET @sql := IF(@idx = 0, 'ALTER TABLE ypd_statistics ADD INDEX idx_statistics_sort (sort_order)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ------------------------------------------------------------------
-- Recycle bin / audit
-- ------------------------------------------------------------------
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'deleted_items' AND INDEX_NAME = 'idx_deleted_entity');
SET @sql := IF(@idx = 0, 'ALTER TABLE deleted_items ADD INDEX idx_deleted_entity (entity_table, entity_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
