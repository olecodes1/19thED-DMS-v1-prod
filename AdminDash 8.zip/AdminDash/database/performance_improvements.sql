-- ============================================================
-- PERFORMANCE IMPROVEMENTS — 19th Episcopal District
-- Strategy: (1) Pre-aggregate hot queries into summary tables,
--          (2) Composite indexes, (3) Partial indexes for filtered counts
--          (4) Remove expensive correlated subqueries
-- Safe to re-run (checks existence before creating/overwriting)
-- ============================================================

SET @db = DATABASE();

-- ============================================================
-- SECTION 1: SUMMARY TABLE — Dashboard / Landing stats
-- Covers the 5 most expensive aggregation queries on every page load
-- ============================================================

-- 1a. Per-church member counts (replaces correlated subquery ×3 per church)
CREATE TABLE IF NOT EXISTS church_member_summary (
    church_id INT PRIMARY KEY,
    member_count INT NOT NULL DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_church_member_count (member_count)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Populate (run after data changes; add a stored procedure later if needed)
-- INSERT INTO church_member_summary (church_id, member_count)
-- SELECT church_id, COUNT(*) FROM members GROUP BY church_id;

-- 1b. District-wide aggregates (single row, refreshable)
CREATE TABLE IF NOT EXISTS district_aggregates (
    id INT PRIMARY KEY DEFAULT 1,
    total_members INT NOT NULL DEFAULT 0,
    active_churches INT NOT NULL DEFAULT 0,
    inactive_churches INT NOT NULL DEFAULT 0,
    total_conferences INT NOT NULL DEFAULT 0,
    total_areas INT NOT NULL DEFAULT 0,
    total_events INT NOT NULL DEFAULT 0,
    total_media INT NOT NULL DEFAULT 0,
    total_stories INT NOT NULL DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO district_aggregates (id, total_members, active_churches, inactive_churches, total_conferences, total_areas, total_events, total_media, total_stories)
VALUES (1, 0, 0, 0, 0, 0, 0, 0, 0)
ON DUPLICATE KEY UPDATE id = VALUES(id);

-- ============================================================
-- SECTION 2: COMPOSITE & PARTIAL INDEXES
-- ============================================================

-- Members — composite indexes for filter combinations
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_conference_component');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_conference_component (conference_id, component)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_deleted_joined');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_deleted_joined (deleted_at, joined_ypd)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'members' AND INDEX_NAME = 'idx_members_occupation');
SET @sql := IF(@idx = 0, 'ALTER TABLE members ADD INDEX idx_members_occupation (occupational_status)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Churches — index for activity filter (member_count pre-aggregated)
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'churches' AND INDEX_NAME = 'idx_churches_area_conference');
SET @sql := IF(@idx = 0, 'ALTER TABLE churches ADD INDEX idx_churches_area_conference (area_id, conference_id)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'churches' AND INDEX_NAME = 'idx_churches_status');
SET @sql := IF(@idx = 0, 'ALTER TABLE churches ADD INDEX idx_churches_status (status)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Media — index for category + year filter
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'media_items' AND INDEX_NAME = 'idx_media_cat_year');
SET @sql := IF(@idx = 0, 'ALTER TABLE media_items ADD INDEX idx_media_cat_year (category, media_year)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Events — index for date + name search
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'events' AND INDEX_NAME = 'idx_events_date_name');
SET @sql := IF(@idx = 0, 'ALTER TABLE events ADD INDEX idx_events_date_name (event_date, event_name)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Story pages — index for slug + published
SET @idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = @db AND TABLE_NAME = 'story_pages' AND INDEX_NAME = 'idx_stories_published');
SET @sql := IF(@idx = 0, 'ALTER TABLE story_pages ADD INDEX idx_stories_published (status, deleted_at)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ============================================================
-- SECTION 3: REFRESH STATEMENTS (run after data changes)
-- These replace the expensive inline queries
-- ============================================================

-- District aggregates
UPDATE district_aggregates
SET total_members = (SELECT COUNT(*) FROM members WHERE deleted_at IS NULL),
    active_churches = (SELECT COUNT(*) FROM churches c
        WHERE (SELECT COUNT(*) FROM members m WHERE m.church_id = c.church_id) >= 1),
    inactive_churches = (SELECT COUNT(*) FROM churches c
        WHERE (SELECT COUNT(*) FROM members m WHERE m.church_id = c.church_id) = 0),
    total_conferences = (SELECT COUNT(*) FROM conferences),
    total_areas = (SELECT COUNT(*) FROM areas),
    total_events = (SELECT COUNT(*) FROM events),
    total_media = (SELECT COUNT(*) FROM media_items WHERE deleted_at IS NULL),
    total_stories = (SELECT COUNT(*) FROM story_pages WHERE deleted_at IS NULL AND status = 'published');

-- Church member counts (batch, not correlated). Delete first so churches
-- whose last member was removed do not retain a stale summary row.
DELETE FROM church_member_summary;
INSERT INTO church_member_summary (church_id, member_count)
SELECT m.church_id, COUNT(*)
FROM members m
WHERE m.deleted_at IS NULL
GROUP BY m.church_id
ON DUPLICATE KEY UPDATE member_count = VALUES(member_count);

-- ============================================================
-- SECTION 4: OPTIMIZED VIEWS (swap for inline queries)
-- ============================================================

-- Use these as replacements for the heavy inline queries:
-- Dashboard: SELECT * FROM district_aggregates; → just reads 1 row
-- Church activity: JOIN church_member_summary instead of correlated subquery
-- ============================================================
