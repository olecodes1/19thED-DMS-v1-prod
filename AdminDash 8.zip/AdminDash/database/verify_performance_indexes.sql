-- Run after add_performance_indexes.sql and performance_improvements.sql.
-- This is read-only and lists the expected indexes for verification.
SELECT TABLE_NAME, INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS indexed_columns
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND INDEX_NAME IN (
    'idx_members_church', 'idx_members_conference_component',
    'idx_members_deleted_joined', 'idx_members_deleted_church',
    'idx_events_date', 'idx_events_conference', 'idx_events_conference_date',
    'idx_breakdowns_event', 'idx_breakdowns_event_attendance',
    'idx_media_deleted_at', 'idx_media_deleted_uploaded', 'idx_media_cat_year',
    'idx_story_deleted_at', 'idx_story_status_deleted_created', 'idx_stories_published',
    'idx_churches_area_conference', 'idx_churches_status'
  )
GROUP BY TABLE_NAME, INDEX_NAME
ORDER BY TABLE_NAME, INDEX_NAME;
